const mongoose = require('mongoose');

const videoSchema = new mongoose.Schema({
  title: String,
  description: String,
  videoUrl: String,
  uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  uploadDate: { type: Date, default: Date.now },
  views: { type: Number, default: 0 },
  category: { type: String, required: true }
});

module.exports = mongoose.model('Video', videoSchema);
