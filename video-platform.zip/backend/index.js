const express = require('express');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const AWS = require('aws-sdk');
const multer = require('multer');
const multerS3 = require('multer-s3');
const path = require('path');
require('dotenv').config();

const app = express();

// Middleware
app.use(express.json());

// Database setup
mongoose.connect('mongodb://localhost:27017/video_platform', { useNewUrlParser: true, useUnifiedTopology: true });

// Models
const User = require('./models/user');
const Video = require('./models/video');

// AWS S3 setup
const s3 = new AWS.S3({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: 'us-west-1'
});

const upload = multer({
  storage: multerS3({
    s3: s3,
    bucket: 'your-bucket-name',
    acl: 'public-read',
    key: function (req, file, cb) {
      cb(null, `${Date.now().toString()}${path.extname(file.originalname)}`);
    }
  }),
  fileFilter: function (req, file, cb) {
    const filetypes = /mp4|mov|avi/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    if (extname) {
      return cb(null, true);
    } else {
      cb('Error: Videos Only!');
    }
  }
});

// Authentication Middleware
const authenticateJWT = (req, res, next) => {
  const token = req.header('Authorization');
  if (!token) return res.status(401).send('Access denied');

  try {
    const verified = jwt.verify(token, process.env.JWT_SECRET);
    req.user = verified;
    next();
  } catch (err) {
    res.status(400).send('Invalid token');
  }
};

// Routes
app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username, password });
  if (!user) return res.status(400).send('Invalid credentials');

  const token = jwt.sign({ _id: user._id, role: user.role }, process.env.JWT_SECRET);
  res.send({ token });
});

app.post('/admin/upload', authenticateJWT, upload.single('video'), async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).send('Access forbidden');

  const video = new Video({
    title: req.body.title,
    description: req.body.description,
    videoUrl: req.file.location,
    uploadedBy: req.user._id,
    category: req.body.category
  });

  await video.save();
  res.send(video);
});

app.get('/videos', async (req, res) => {
  const { search, sort, category } = req.query;

  let filter = {};
  if (search) {
    filter.title = { $regex: search, $options: 'i' };
  }
  if (category) {
    filter.category = category;
  }

  let sortOption = {};
  if (sort === 'date') {
    sortOption = { uploadDate: -1 };
  } else if (sort === 'popularity') {
    sortOption = { views: -1 };
  }

  const videos = await Video.find(filter).sort(sortOption).populate('uploadedBy', 'username');
  res.send(videos);
});

app.get('/categories', async (req, res) => {
  const categories = await Video.distinct('category');
  res.send(categories);
});

app.delete('/admin/videos/:id', authenticateJWT, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).send('Access forbidden');

  const video = await Video.findByIdAndDelete(req.params.id);
  if (!video) return res.status(404).send('Video not found');

  res.send({ message: 'Video deleted successfully' });
});

app.put('/admin/videos/:id', authenticateJWT, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).send('Access forbidden');

  const { title, description } = req.body;
  const video = await Video.findByIdAndUpdate(
    req.params.id,
    { title, description },
    { new: true }
  );

  if (!video) return res.status(404).send('Video not found');

  res.send(video);
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
