import React from 'react';
import AdminPanel from './components/AdminPanel';
import ManageVideos from './components/ManageVideos';

function App() {
  return (
    <div className="App">
      <AdminPanel />
      <ManageVideos />
    </div>
  );
}

export default App;
