import React, { useState, useEffect } from 'react';

function ManageVideos() {
  const [videos, setVideos] = useState([]);
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState('date');
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchCategories();
    fetchVideos();
  }, [search, sort, selectedCategory]);

  const fetchVideos = async () => {
    try {
      const res = await fetch(`http://localhost:3000/videos?search=${search}&sort=${sort}&category=${selectedCategory}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      });
      const data = await res.json();
      setVideos(data);
    } catch (err) {
      console.error('Error fetching videos:', err);
    }
  };

  const fetchCategories = async () => {
    try {
      const res = await fetch('http://localhost:3000/categories');
      const data = await res.json();
      setCategories(data);
    } catch (err) {
      console.error('Error fetching categories:', err);
    }
  };

  const handleSearchChange = (e) => {
    setSearch(e.target.value);
  };

  const handleSortChange = (e) => {
    setSort(e.target.value);
  };

  const handleCategoryChange = (e) => {
    setSelectedCategory(e.target.value);
  };

  return (
    <div>
      <h1>Manage Videos</h1>
      {message && <p>{message}</p>}

      <div>
        <input
          type="text"
          placeholder="Search by title..."
          value={search}
          onChange={handleSearchChange}
        />
        <select value={sort} onChange={handleSortChange}>
          <option value="date">Sort by Date</option>
          <option value="popularity">Sort by Popularity</option>
        </select>
        <select value={selectedCategory} onChange={handleCategoryChange}>
          <option value="">All Categories</option>
          {categories.map((category) => (
            <option key={category} value={category}>
              {category}
            </option>
          ))}
        </select>
      </div>

      <div>
        {videos.map((video) => (
          <div key={video._id}>
            <h3>{video.title}</h3>
            <p>{video.description}</p>
            <p>Category: {video.category}</p>
            <video controls src={video.videoUrl} width="400"></video>
            <p>Views: {video.views}</p>
            <button>Edit</button>
            <button>Delete</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ManageVideos;
